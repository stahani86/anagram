package com.jpmc.entities;

import java.math.BigDecimal;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;

public class JpaTest {

	public static void main(String[] args) {
		EntityManagerFactory emf = JpaUtil.getEntityManagerFactory();
		EntityManager entityManager = emf.createEntityManager();
		EntityTransaction transaction = entityManager.getTransaction();
		
		Emp e = new Emp();
		e.setId(new BigDecimal(7));
		e.setName("Ganesh");
		e.setSalary(new BigDecimal(7777.77));

		transaction.begin();
		entityManager.persist(e);
		transaction.commit();
		entityManager.close();
		JpaUtil.closeEntityManagerFactory();
				
	}

}
