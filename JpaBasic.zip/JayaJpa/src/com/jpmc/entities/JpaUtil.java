package com.jpmc.entities;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class JpaUtil {

	private static EntityManagerFactory entityManagerFactory;
	
	public static void initializeEntityManagerFactory() {
		if(entityManagerFactory == null) {
			try{
				entityManagerFactory = Persistence.createEntityManagerFactory("JayaJpa");
			}catch(Exception e){
				e.printStackTrace();
			}
		}
	}
	
	public static void closeEntityManagerFactory() {
		if(entityManagerFactory != null) {
			try{
				entityManagerFactory.close();
				System.out.println("Entity Manager Factory is closed");
			}catch(Exception e){
				e.printStackTrace();
			}
		}
	}
	
	public static synchronized EntityManagerFactory getEntityManagerFactory() {
			try{
				if(entityManagerFactory == null) {
					JpaUtil.initializeEntityManagerFactory();
				}
			}catch(Exception e){
				e.printStackTrace();
			}
		return entityManagerFactory;
	}
}
