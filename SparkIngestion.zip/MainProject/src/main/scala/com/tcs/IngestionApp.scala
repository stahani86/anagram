package com.tcs

import com.tcs.util.PropertyUtils
import java.util.Properties
import com.tcs.util.JdbcUtils
import com.tcs.beans.IngestionMaster
import org.apache.spark.sql.SparkSession
import java.time.LocalDate
import java.time.DayOfWeek

import org.apache.spark.sql.functions.max
import com.tcs.beans.IngestionTracker
import org.apache.log4j.spi.RootLogger
import org.apache.log4j.Logger
import org.apache.log4j.Level

object IngestionApp {

  def main(args: Array[String]): Unit = {

    PropertyUtils.initProperties()

    val ingestionList: List[IngestionMaster] = JdbcUtils.getIngestionMasterData()

    val props = new Properties
    props.setProperty("user", PropertyUtils.getProperty("source_user"))
    props.setProperty("password", PropertyUtils.getProperty("source_password"))
    props.setProperty("driver", PropertyUtils.getProperty("source_driver"))
    val url = PropertyUtils.getProperty("source_url")

    //   val ingestionTracker = JdbcUtils.IngestionTrackerData(connProps)
    val spark = SparkSession.builder().appName("ingestion_App").master("local[*]").enableHiveSupport().getOrCreate()
    spark.sparkContext.setLogLevel("ERROR")
    Logger.getRootLogger.setLevel(Level.ERROR)
    ingestionList.foreach(a => {
      println(a)
      val table = a.source_table
      val hive_table = a.target_hive_table
      val sourceDF = spark.read.jdbc(url, table, props)
      val load_frequency = a.load_frequency
      println(s"load_frequency is :${load_frequency}")
      val load_type = a.load_type
      println(s"load_type is :$load_type")
      var writeMode: String = null
      if (load_type == "INCREMENTALAPPEND" || load_type == "APPEND") {
        writeMode = "APPEND"
      } else {
        writeMode = "OVERWRITE"
      }
      if (load_frequency.equalsIgnoreCase("D")) {
        val tracker: IngestionTracker = JdbcUtils.insertIngestionTrackerDataRecord(a)
        try {
          val hiveDF = spark.read.table(hive_table)
          println(s"${hive_table} exists with count = ${hiveDF.count}")
          println(s"Now inserting records into hive table : ${hive_table}")
          sourceDF.write.mode(s"$writeMode").format("orc").insertInto(hive_table)
        } catch {
          case e: Exception => {
            println(s"${hive_table} doesnot exists")
            sourceDF.write.mode(s"$writeMode").format("orc").saveAsTable(hive_table)
          }
        }
        if (load_type.equalsIgnoreCase("INCREMENTALAPPEND")) {
          val maxValDF = sourceDF.selectExpr(s"COALESCE(MAX(${a.ref_column}), 0) as max")
          val row = maxValDF.collect()(0)
          val maxValue = row.getInt(row.fieldIndex("max"))
          tracker.setLast_incremental_value(maxValue)
        }
        JdbcUtils.updateIngestionTrackerDataRecord(tracker)
        println(s"data ingestion done for jdbc: $table into hive table : $hive_table")
      } else if (load_frequency.trim().equalsIgnoreCase("W")) {
        val dayOfWeek: Int = LocalDate.now().getDayOfWeek.getValue
        println(s"dayOfWeek=$dayOfWeek")
        if (dayOfWeek == 3) {
          val tracker: IngestionTracker = JdbcUtils.insertIngestionTrackerDataRecord(a)
          try {
            val hiveDF = spark.read.table(hive_table)
            println(s"${hive_table} exists with count = ${hiveDF.count}")
            println(s"Now inserting records into hive table : ${hive_table}")
            sourceDF.write.mode(s"$writeMode").format("orc").insertInto(hive_table)
          } catch {
            case e: Exception => {
              println(s"${hive_table} doesnot exists")
              sourceDF.write.mode(s"$writeMode").format("orc").saveAsTable(hive_table)
            }
          }
          if (load_type.equalsIgnoreCase("INCREMENTALAPPEND")) {
            val maxValDF = sourceDF.selectExpr(s"COALESCE(MAX(${a.ref_column}), 0) as max")
            val row = maxValDF.collect()(0)
            val maxValue = row.getInt(row.fieldIndex("max"))
            tracker.setLast_incremental_value(maxValue)
          }
          JdbcUtils.updateIngestionTrackerDataRecord(tracker)
          println(s"data ingestion done for jdbc: $table into hive table : $hive_table")
        }
      } else if (load_frequency.equalsIgnoreCase("M")) {
        val dayOfMonth: Int = LocalDate.now().getDayOfMonth
        println(s"dayOfMonth=$dayOfMonth")
        if (dayOfMonth == 1) {
          val tracker: IngestionTracker = JdbcUtils.insertIngestionTrackerDataRecord(a)
          try {
            val hiveDF = spark.read.table(hive_table)
            println(s"${hive_table} exists with count = ${hiveDF.count}")
            println(s"Now inserting records into hive table : ${hive_table}")
            sourceDF.write.mode(s"$writeMode").format("orc").insertInto(hive_table)
          } catch {
            case e: Exception => {
              println(s"${hive_table} doesnot exists")
              sourceDF.write.mode(s"$writeMode").format("orc").saveAsTable(hive_table)
            }
          }
          if (load_type.equalsIgnoreCase("INCREMENTALAPPEND")) {
            val maxValDF = sourceDF.selectExpr(s"COALESCE(MAX(${a.ref_column}), 0) as max")
            val row = maxValDF.collect()(0)
            val maxValue = row.getDecimal(row.fieldIndex("max"))
            tracker.setLast_incremental_value(maxValue.intValue())
          }
          JdbcUtils.updateIngestionTrackerDataRecord(tracker)
          println(s"data ingestion done for jdbc: $table into hive table : $hive_table")
        }
      } else {
        println(s"loadfrequency= $load_frequency is not recognized")
      }

    })
  }
}