package com.tcs

import java.util.Properties
import java.io.FileInputStream
import java.io.IOException

object PropertyTester {

  def main(args: Array[String]): Unit = {

    try {
      val input = PropertyTester.getClass.getClassLoader().getResourceAsStream("application.properties")
      val props = new Properties

      //load a property
      props.load(input)

      println(props.getProperty("user"))
      println(props.getProperty("password"))
      println(props.getProperty("url"))
      println(props.getProperty("driver"))


    } catch {
      case ioe: IOException => ioe.printStackTrace()
      case e: Exception     => e.printStackTrace()
    }
  }

}