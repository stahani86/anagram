package com.tcs

import java.time.LocalDate
import java.time.DayOfWeek
import com.tcs.util.PropertyUtils
import java.sql.Connection
import java.sql.DriverManager
import java.sql.Statement

object testApp {
  def main(args: Array[String]): Unit = {

     val dayOfWeek: Int = LocalDate.now().getDayOfWeek.getValue
     println(dayOfWeek)
  }
}