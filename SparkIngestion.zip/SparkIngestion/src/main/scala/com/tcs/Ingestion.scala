package com.tcs

import java.util.Properties
import java.sql.ResultSet
import java.sql.Connection
import java.sql.Statement
import java.sql.DriverManager

object Ingestion {

  def main(args: Array[String]): Unit = {

    val url = "jdbc:mysql://192.168.115.135:3306/kankipati"
    val driver = "com.mysql.jdbc.Driver"
    val username = "gopal"
    val password = "gopal@123"
    var connection: Connection = null
    try {
      Class.forName(driver)
      connection = DriverManager.getConnection(url, username, password)
      val statement = connection.createStatement
      var resultset = statement.executeQuery("SELECT * from employee1")

      while (resultset.next) {
        val id = resultset.getInt("id")
        val name = resultset.getString("name")
        val sal = resultset.getInt("sal")
        println(id + "," + name + "," + sal)
      }

    } catch {
      case e: Exception => e.printStackTrace
    }
    connection.close
  }
}

