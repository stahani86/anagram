package com.tcs.beans

import scala.beans.BeanProperty

class IngestionMaster {
  
 @BeanProperty var sno:Int=_
 @BeanProperty var source_table:String=_
 @BeanProperty var ref_column:String=_
 @BeanProperty var target_hive_table:String=_
 @BeanProperty var target_hive_partition:String=_
 @BeanProperty var load_type:String=_
 @BeanProperty var load_frequency:String=_
 

override def toString():String={
   s"""
   sno=${sno}
   source_table=${source_table}
   ref_column=${ref_column}
   target_hive_table=${target_hive_table}
   target_hive_partition=${target_hive_partition}
   load_type=${load_type}
   load_frequency=${load_frequency}  
   """
 }
}