package com.tcs.beans

import scala.beans.BeanProperty

class IngestionTracker {
  
 @BeanProperty var sno:Int=_
 @BeanProperty var source_table:String=_
 @BeanProperty var ref_column:String=_
 @BeanProperty var target_hive_table:String=_
 @BeanProperty var target_hive_partition:String=_
 @BeanProperty var load_type:String=_
 @BeanProperty var load_frequency:String=_
 @BeanProperty var last_incremental_value:Int=_
 @BeanProperty var starts_ts:String=_
 @BeanProperty var end_ts:String=_
 @BeanProperty var status:String=_
 @BeanProperty var error_msg:String=_
}

