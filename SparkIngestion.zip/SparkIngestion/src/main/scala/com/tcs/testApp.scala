package com.tcs

import java.time.LocalDate
import java.time.DayOfWeek
import com.tcs.util.PropertyUtils
import java.sql.Connection
import java.sql.DriverManager
import java.sql.Statement

object testApp {
  def main(args: Array[String]): Unit = {

    PropertyUtils.initProperties()
    val user = PropertyUtils.getProperty("ingestion_user")
    val password = PropertyUtils.getProperty("ingestion_password")
    val url = PropertyUtils.getProperty("ingestion_url")
    val driver = PropertyUtils.getProperty("ingestion_driver")
    val tracker_table = PropertyUtils.getProperty("ingestion_tracker_table")
    var connection: Connection = null
    var statement: Statement = null
    try {
      Class.forName(driver)
      connection = DriverManager.getConnection(url, user, password)
      statement = connection.createStatement()
      // val query = s"insert into $tracker_table (sno ,source_table ,ref_column ,target_hive_table , target_hive_partition ,load_type ,load_frequency ,last_incremental_value ,end_ts ,status ,error_msg) values(3,'sales','sno','sales',null,'append','D',10,current_timestamp(),'success',null)"
      val query = s"update $tracker_table set load_frequency='M' where sno=3"
      statement.executeUpdate(query)
      println("row inserted")
    } catch {
      case e: Exception => e.printStackTrace()
    } finally {
      statement.close()
      connection.close()
    }
  }
}