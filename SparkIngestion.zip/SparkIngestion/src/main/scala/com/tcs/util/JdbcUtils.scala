package com.tcs.util

import java.sql.DriverManager
import java.sql.Connection
import java.sql.Statement
import java.sql.ResultSet
import com.tcs.beans.IngestionMaster
import java.util.ArrayList
import java.util.Properties
import com.tcs.beans.IngestionTracker

object JdbcUtils {

  def getIngestionMasterData(): List[IngestionMaster] = {

    val url = PropertyUtils.getProperty("ingestion_url")
    val user = PropertyUtils.getProperty("ingestion_user")
    val password = PropertyUtils.getProperty("ingestion_password")
    val driver = PropertyUtils.getProperty("ingestion_driver")
    val master_table: String = PropertyUtils.getProperty("ingestion_master_table")
    var connection: Connection = null
    var statement: Statement = null
    var resultSet: ResultSet = null

    val list = new ArrayList[IngestionMaster]()
    try {
      Class.forName(driver)
      connection = DriverManager.getConnection(url, user, password)
      statement = connection.createStatement()
      resultSet = statement.executeQuery(s"select * from ${master_table}")

      if (resultSet.next()) {
        do {
          val ingestionMaster = new IngestionMaster
          ingestionMaster.setSno(resultSet.getInt(1))
          ingestionMaster.setSource_table(resultSet.getString(2))
          ingestionMaster.setRef_column(resultSet.getString(3))
          ingestionMaster.setTarget_hive_table(resultSet.getString(4))
          ingestionMaster.setTarget_hive_partition(resultSet.getString(5))
          ingestionMaster.setLoad_type(resultSet.getString(6))
          ingestionMaster.setLoad_frequency(resultSet.getString(7))

          list.add(ingestionMaster)
        } while (resultSet.next())
      } else {
        println("Record Not Found...")
      }

    } catch {
      case e: Exception => e.printStackTrace()
    } finally {
      resultSet.close()
      statement.close()
      connection.close()
    }

    import collection.JavaConverters._

    list.asScala.toList
    
  }
  def insertIngestionTrackerDataRecord(master: IngestionMaster):IngestionTracker={
    var sno :Int = 0
    
    val user = PropertyUtils.getProperty("ingestion_user")
    val password = PropertyUtils.getProperty("ingestion_password")
    val url = PropertyUtils.getProperty("ingestion_url")
    val driver = PropertyUtils.getProperty("ingestion_driver")
    val tracker_table = PropertyUtils.getProperty("ingestion_tracker_table")
    var con: Connection = null
    var stmt: Statement = null
    var rs:ResultSet = null
    val tracker : IngestionTracker = new IngestionTracker
    tracker.setSource_table(master.getSource_table())
    tracker.setRef_column(master.getRef_column())
    tracker.setTarget_hive_table(master.getTarget_hive_table())
    tracker.setTarget_hive_partition(master.getTarget_hive_partition())
    tracker.setLoad_type(master.load_type)
    tracker.setLoad_frequency(master.load_frequency)
    tracker.setStarts_ts("CURRENT_TIMESTAMP()")
    tracker.setStatus("IN-PROGRESS")
    try {
      Class.forName(driver)
      con = DriverManager.getConnection(url, user, password)
      stmt = con.createStatement()
      val maxSnoQuery = s"select MAX(NVL(sno, 0)) from ${tracker_table}"
      rs = stmt.executeQuery(maxSnoQuery)
      if(rs.next()){
        val maxSno:Int = rs.getInt(1)
        sno = maxSno + 1
         tracker.setSno(sno)
      }
      rs.close()
      stmt.close()
      
      val insertQuery = s"""insert into $tracker_table  
        (
        sno,
        source_table,
        ref_column,
        target_hive_table,
        target_hive_partition,
        load_type,
        load_frequency,
        last_incremental_value,
        starts_ts,
        end_ts,
        status,
        error_msg
        )
        values 
        (
        ${tracker.getSno()},
        ${tracker.getSource_table()},
        ${tracker.getRef_column()},
        ${tracker.getTarget_hive_table()},
        ${tracker.getTarget_hive_partition()},
        ${tracker.getLoad_type()},
        ${tracker.getLoad_frequency()},
        null,
        ${tracker.getStarts_ts()},
        null,
        ${tracker.getStatus()},
        null
        )
      """.stripMargin
      
      println(s"insertQuery : ${insertQuery}")
      stmt = con.createStatement()
      val recordsInserted = stmt.executeQuery(insertQuery)
      println(s"No of records inserted are : ${recordsInserted}")
      stmt.close()
     } catch {
      case e: Exception => e.printStackTrace()
    } finally {
      con.close()
    }
    return tracker
  }
  
  def updateIngestionTrackerDataRecord(tracker: IngestionTracker):IngestionTracker={
    val user = PropertyUtils.getProperty("ingestion_user")
    val password = PropertyUtils.getProperty("ingestion_password")
    val url = PropertyUtils.getProperty("ingestion_url")
    val driver = PropertyUtils.getProperty("ingestion_driver")
    val tracker_table = PropertyUtils.getProperty("ingestion_tracker_table")
    var con: Connection = null
    var stmt: Statement = null
    var rs:ResultSet = null
    
    tracker.setEnd_ts("CURRENT_TIMESTAMP()")
    tracker.setStatus("SUCCESS")
    try {
      Class.forName(driver)
      con = DriverManager.getConnection(url, user, password)
      
      val updateQuery = s"""update $tracker_table  SET 
        last_incremental_value=${tracker.getLast_incremental_value()}
        end_ts=${tracker.getEnd_ts()},
        status='${tracker.getStatus()}'
        WHERE sno=${tracker.getSno()}
      """.stripMargin

      println(s"updateQuery : ${updateQuery}")
      stmt = con.createStatement()
      val recordsUpdated = stmt.executeQuery(updateQuery)
      println(s"No of records updated are : ${recordsUpdated}")
      stmt.close()
      
     } catch {
      case e: Exception => e.printStackTrace()
    } finally {
      con.close()
    }
    return tracker
  }
}