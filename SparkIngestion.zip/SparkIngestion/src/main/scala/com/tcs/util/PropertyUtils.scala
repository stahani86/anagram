package com.tcs.util

import java.util.Properties

object PropertyUtils {

  val props = new Properties

  def initProperties(): Unit = {
    try {
      val input = PropertyUtils.getClass.getClassLoader().getResourceAsStream("application.properties")
      props.load(input)
    } catch {
      case e: Exception => e.printStackTrace()
    }

  }
  
  def getProperty(key:String):String={
    val value = props.getProperty(key)
    if(value==null) return ""
    else return value
  }

}