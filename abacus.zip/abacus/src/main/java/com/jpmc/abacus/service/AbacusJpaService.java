package com.jpmc.abacus.service;

public interface AbacusJpaService {
	
}
