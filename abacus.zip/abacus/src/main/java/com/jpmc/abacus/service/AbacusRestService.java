package com.jpmc.abacus.service;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;

import com.jpmc.abacus.beans.AbacusRequest;
import com.jpmc.abacus.beans.AbacusResponse;

public interface AbacusRestService {
	public @ResponseBody ResponseEntity<AbacusResponse> getAbacusResponse(@RequestBody AbacusRequest request);
}
