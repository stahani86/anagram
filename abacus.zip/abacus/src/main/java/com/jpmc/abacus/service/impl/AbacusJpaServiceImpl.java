package com.jpmc.abacus.service.impl;

import com.jpmc.abacus.service.AbacusJpaService;

public class AbacusJpaServiceImpl implements AbacusJpaService {
	
}
