package com.jpmc.abacus.service.impl;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.jpmc.abacus.beans.AbacusRequest;
import com.jpmc.abacus.beans.AbacusResponse;
import com.jpmc.abacus.service.AbacusRestService;

@RestController
public class AbacusRestServiceImpl implements  AbacusRestService{
	
	@RequestMapping( method = RequestMethod.POST,  path = "/abacus", produces = {"application/json"}, consumes = {"application/json"})
	public @ResponseBody ResponseEntity<AbacusResponse> getAbacusResponse(@RequestBody AbacusRequest request) {
		
		AbacusResponse abacusResponse = new AbacusResponse();
		if(request == null) {
			abacusResponse.setErrorMessage("The request can not be empty/null");
			abacusResponse.setStatusCode(HttpStatus.NO_CONTENT.value());
			ResponseEntity<AbacusResponse> response = new ResponseEntity<AbacusResponse>(abacusResponse, HttpStatus.NO_CONTENT);
			return response;
		}
		else if(StringUtils.isEmpty(request.getQuery()) ) {
			abacusResponse.setErrorMessage("Query can not be empty/null");
			abacusResponse.setStatusCode(HttpStatus.BAD_REQUEST.value());
			ResponseEntity<AbacusResponse> response = new ResponseEntity<AbacusResponse>(abacusResponse, HttpStatus.BAD_REQUEST);
			return response;
		}
		else if(request.getQuery().length()>=1024 ) {
			abacusResponse.setErrorMessage("Query must be < 1024 characters in length");
			abacusResponse.setStatusCode(HttpStatus.NOT_ACCEPTABLE.value());
			ResponseEntity<AbacusResponse> response = new ResponseEntity<AbacusResponse>(abacusResponse, HttpStatus.NOT_ACCEPTABLE);
			return response;
		}else {
			// methodcall
			
			ResponseEntity<AbacusResponse> response = new ResponseEntity<AbacusResponse>(abacusResponse, HttpStatus.OK);
			return response;
		}	
	}
	
}
