package com.xyz

import java.io.File
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

import org.apache.log4j.Logger
import org.apache.log4j.Level

import org.apache.spark.sql.SaveMode
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions.{lit, row_number, col, udf}
import org.apache.spark.sql.expressions.Window

import com.fidelity.s3process.util.LoggerUtils
import com.fidelity.s3process.util.PropertyUtils
import org.apache.spark.sql.types.DataTypes

object App {

  val log: Logger = Logger.getLogger(App.getClass)

  def main(args: Array[String]) {
    val startTime = System.currentTimeMillis()
    val startTimestamp: String = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))
    println("started at : " + startTimestamp)
    System.setProperty("hadoop.home.dir", "D:\\Jagadeesh\\hadoop\\winutils-master\\hadoop-2.8.3")
    // Loading properties from application.properties
    //PropertyUtils.initProperties("local.application.properties")
    PropertyUtils.initProperties("application.properties")
    // Configuring for Log4j
    LoggerUtils.configure(PropertyUtils.getProperty("log4jConfigPath"))
    
    //Getting spark session
    val spark = SparkSession.builder.appName("s3app").master("local[*]").getOrCreate()

    //spark.sparkContext.setLogLevel("INFO")
    
    var xmlDF = spark.read.format("com.databricks.spark.xml") 
              .option("rootTag", "references-cited") 
              .option("rowTag", "citation") 
              .load("file:///D:/Jagadeesh/parT/Ashok/ipg101026.xml")
    
    xmlDF = xmlDF.withColumn("Application_Type", lit("General").cast(DataTypes.StringType))
    
    var resultDF = xmlDF.select(    
                                col("category"), 
                                col("patcit.document-id.country").as("country"),
                                col("patcit.document-id.doc-number").as("Application_Number"),
                                col("Application_Type")
                               )
                        .where(col("Application_Number").isNotNull) 
   
    resultDF = resultDF.withColumn("SerialNumber", row_number().over(Window.orderBy("Application_Number")))
    
    def getAppStatus(a:String):String={
      //scala rest client call
      "0"
    }
    
    val getAppStatusUDF = udf(getAppStatus(_:String))
  
    val finalDF = resultDF.withColumn("appStatus", getAppStatusUDF(col("Application_Number")))
    
    finalDF.printSchema()
    
    finalDF.show()
    
    finalDF.write.saveAsTable("results")
   
    spark.stop();
    
    val totalTimeConsumedInSecs = (System.currentTimeMillis() - startTime) / 1000
    println(s"Total Time consumed :  $totalTimeConsumedInSecs seconds")
    print("Ended at : " + LocalDateTime.now())
  }
}