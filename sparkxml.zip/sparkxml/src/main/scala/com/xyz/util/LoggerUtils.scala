package com.xyz.util

import org.apache.log4j.Logger
import java.io.InputStream
import java.io.IOException
import org.apache.log4j.Level
import org.apache.log4j.PropertyConfigurator

object LoggerUtils {

	def configure(log4jFilePath:String):Unit={
		try {
		  val inputStream:InputStream  = PropertyUtils.getClass.getClassLoader().getResourceAsStream(log4jFilePath)
		  PropertyConfigurator.configure(inputStream)
		}catch  {
		  case e: Exception  => e.printStackTrace()
		}
	}
}